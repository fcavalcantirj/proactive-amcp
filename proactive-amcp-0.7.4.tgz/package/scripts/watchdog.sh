#!/bin/bash
# watchdog.sh - Health check, diagnosis, and intelligent recovery
# Usage: ./watchdog.sh [--continuous]
#
# Uses diagnose.sh to detect issues, then routes to the right fix:
#   session_corrupted → session-fix.sh + gateway restart (lightweight)
#   gateway_down      → full resurrection
#   gateway_unresponsive → gateway restart
#   config_invalid    → resurrection (config fix tier)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AMCP_CLI="${AMCP_CLI:-$(command -v amcp 2>/dev/null || echo "$HOME/bin/amcp")}"
IDENTITY_PATH="${IDENTITY_PATH:-$HOME/.amcp/identity.json}"
STATE_FILE="$HOME/.amcp/watchdog-state.json"
LOCK_FILE="$HOME/.amcp/resurrection.lock"
AGENT_NAME="${AGENT_NAME:-ClaudiusThePirateEmperor}"
CONTINUOUS="${1:-}"
CHECK_INTERVAL="${CHECK_INTERVAL:-60}"  # seconds
FAIL_THRESHOLD="${FAIL_THRESHOLD:-2}"   # consecutive failures before DEAD
RETRY_DELAY_INITIAL="${RETRY_DELAY_INITIAL:-300}"  # 5 min initial retry delay
RETRY_DELAY_MAX="${RETRY_DELAY_MAX:-1800}"          # 30 min max retry delay

# ============================================================
# Identity pre-flight — validate before operating
# ============================================================
validate_identity() {
  if [ ! -f "$IDENTITY_PATH" ]; then
    echo "FATAL: Invalid AMCP identity — run amcp identity create or amcp identity validate for details"
    exit 1
  fi
  if ! "$AMCP_CLI" identity validate --identity "$IDENTITY_PATH" 2>/dev/null; then
    echo "FATAL: Invalid AMCP identity — run amcp identity create or amcp identity validate for details"
    exit 1
  fi
}

validate_identity

# Warn if secrets found in identity.json (they belong in config.json)
warn_identity_secrets() {
  python3 -c "
import json, os, sys
p = os.path.expanduser('$IDENTITY_PATH')
if not os.path.exists(p): sys.exit(0)
d = json.load(open(p))
bad = [k for k in d if k in ('pinata_jwt','pinata_api_key','solvr_api_key','api_key','apiKey','jwt','token','secret','password','mnemonic','email','notifyTarget')]
if bad:
    print(f'WARNING: Secrets found in identity.json: {\", \".join(bad)}', file=sys.stderr)
    print('  Migrate with: proactive-amcp config set <key> <value>', file=sys.stderr)
" 2>&1 || true
}
warn_identity_secrets

mkdir -p "$(dirname "$STATE_FILE")"

# Initialize state if not exists
if [ ! -f "$STATE_FILE" ]; then
  cat > "$STATE_FILE" << 'EOJSON'
{
  "state": "HEALTHY",
  "consecutiveFailures": 0,
  "lastCheck": null,
  "lastHealthy": null,
  "resurrectionPid": null,
  "lastResurrectionAttempt": null,
  "retryDelay": 0
}
EOJSON
fi

# ============================================================
# Diagnose — delegates to diagnose.sh, returns structured JSON
# ============================================================
run_diagnosis() {
  local diag_output
  local diag_status=0
  diag_output=$("$SCRIPT_DIR/diagnose.sh" 2>/dev/null) || diag_status=$?
  echo "$diag_output"
  return $diag_status
}

# Extract finding types from diagnose JSON
get_finding_types() {
  local diag_json="$1"
  echo "$diag_json" | python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
    for f in d.get('findings', []):
        print(f['type'])
except:
    pass
"
}

# Extract error summary string from diagnose JSON (for state file)
get_error_summary() {
  local diag_json="$1"
  echo "$diag_json" | python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
    types = [f['type'] for f in d.get('findings', [])]
    print(' '.join(types))
except:
    print('diagnosis_failed')
"
}

# Check if a specific finding type exists
has_finding() {
  local diag_json="$1"
  local finding_type="$2"
  echo "$diag_json" | python3 -c "
import json, sys
d = json.load(sys.stdin)
for f in d.get('findings', []):
    if f['type'] == '$finding_type':
        print('yes')
        exit(0)
print('no')
"
}

# Get the fix command for a finding type
get_fix_command() {
  local diag_json="$1"
  local finding_type="$2"
  echo "$diag_json" | python3 -c "
import json, sys
d = json.load(sys.stdin)
for f in d.get('findings', []):
    if f['type'] == '$finding_type':
        print(f.get('fix_command', ''))
        exit(0)
"
}

# ============================================================
# State management
# ============================================================
update_state() {
  local new_state="$1"
  local failures="$2"
  local errors="$3"

  WATCHDOG_STATE_FILE="$STATE_FILE" \
  WATCHDOG_NEW_STATE="$new_state" \
  WATCHDOG_FAILURES="$failures" \
  WATCHDOG_ERRORS="$errors" \
  python3 << 'EOF'
import json, os
from datetime import datetime

state_file = os.environ["WATCHDOG_STATE_FILE"]
new_state = os.environ["WATCHDOG_NEW_STATE"]
failures = int(os.environ["WATCHDOG_FAILURES"])
errors_str = os.environ["WATCHDOG_ERRORS"]

try:
    with open(state_file) as f:
        state = json.load(f)
except (json.JSONDecodeError, FileNotFoundError):
    state = {"state": "HEALTHY", "consecutiveFailures": 0, "lastCheck": None,
             "lastHealthy": None, "resurrectionPid": None,
             "lastResurrectionAttempt": None, "retryDelay": 0}

state["state"] = new_state
state["consecutiveFailures"] = failures
state["lastCheck"] = datetime.now().isoformat()
state["errors"] = errors_str.split() if errors_str else []
if new_state == "HEALTHY":
    state["lastHealthy"] = datetime.now().isoformat()
    state["retryDelay"] = 0
    state["resurrectionPid"] = None

tmp = state_file + ".tmp"
with open(tmp, "w") as f:
    json.dump(state, f, indent=2)
os.replace(tmp, state_file)
EOF
}

get_state() {
  python3 -c "
import json
try:
    print(json.load(open('$STATE_FILE')).get('state', 'UNKNOWN'))
except (json.JSONDecodeError, FileNotFoundError):
    print('UNKNOWN')
"
}

get_failures() {
  python3 -c "
import json
try:
    print(json.load(open('$STATE_FILE')).get('consecutiveFailures', 0))
except (json.JSONDecodeError, FileNotFoundError):
    print(0)
"
}

# ============================================================
# Resurrection management (lock, PID, retry backoff)
# ============================================================
is_resurrection_running() {
  if [ ! -f "$LOCK_FILE" ]; then
    return 1
  fi
  local pid
  pid=$(cat "$LOCK_FILE" 2>/dev/null || echo "")
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    return 0
  fi
  rm -f "$LOCK_FILE"
  return 1
}

get_retry_delay() {
  python3 -c "
import json
try:
    print(json.load(open('$STATE_FILE')).get('retryDelay', 0))
except (json.JSONDecodeError, FileNotFoundError):
    print(0)
"
}

get_last_resurrection_attempt() {
  python3 -c "
import json
from datetime import datetime
try:
    s = json.load(open('$STATE_FILE'))
except (json.JSONDecodeError, FileNotFoundError):
    print(0)
    exit(0)
ts = s.get('lastResurrectionAttempt')
if ts:
    try:
        print(int(datetime.fromisoformat(ts).timestamp()))
    except:
        print(0)
else:
    print(0)
"
}

record_resurrection_launch() {
  local pid="$1"
  local current_delay
  current_delay=$(get_retry_delay)
  local next_delay
  if [ "$current_delay" -eq 0 ]; then
    next_delay="$RETRY_DELAY_INITIAL"
  else
    next_delay=$((current_delay * 2))
    if [ "$next_delay" -gt "$RETRY_DELAY_MAX" ]; then
      next_delay="$RETRY_DELAY_MAX"
    fi
  fi

  WATCHDOG_STATE_FILE="$STATE_FILE" \
  WATCHDOG_RES_PID="$pid" \
  WATCHDOG_NEXT_DELAY="$next_delay" \
  python3 << 'PYEOF'
import json, os
from datetime import datetime
state_file = os.environ["WATCHDOG_STATE_FILE"]
try:
    with open(state_file) as f:
        state = json.load(f)
except (json.JSONDecodeError, FileNotFoundError):
    state = {"state": "DEAD", "consecutiveFailures": 0, "lastCheck": None,
             "lastHealthy": None, "resurrectionPid": None,
             "lastResurrectionAttempt": None, "retryDelay": 0}
state["resurrectionPid"] = int(os.environ["WATCHDOG_RES_PID"])
state["lastResurrectionAttempt"] = datetime.now().isoformat()
state["retryDelay"] = int(os.environ["WATCHDOG_NEXT_DELAY"])
tmp = state_file + ".tmp"
with open(tmp, "w") as f:
    json.dump(state, f, indent=2)
os.replace(tmp, state_file)
PYEOF
}

launch_resurrection() {
  if is_resurrection_running; then
    echo "⏳ Resurrection already in progress (PID $(cat "$LOCK_FILE"))"
    return 0
  fi
  echo "🔄 Launching resurrection..."
  "$SCRIPT_DIR/resuscitate.sh" &
  local res_pid=$!
  record_resurrection_launch "$res_pid"
  echo "🔄 Resurrection PID: $res_pid"
}

should_retry_resurrection() {
  local retry_delay
  retry_delay=$(get_retry_delay)
  if [ "$retry_delay" -eq 0 ]; then
    return 0
  fi
  local last_attempt
  last_attempt=$(get_last_resurrection_attempt)
  local now
  now=$(date +%s)
  local elapsed=$((now - last_attempt))
  if [ "$elapsed" -ge "$retry_delay" ]; then
    return 0
  fi
  echo "⏳ Retry cooldown: ${elapsed}s / ${retry_delay}s"
  return 1
}

# ============================================================
# Error condensing — use Groq to shorten error msgs in notifications
# ============================================================
condense_error_msg() {
  local msg="$1"
  # Only condense if condense-error.sh exists and message is long
  if [ "${#msg}" -le 100 ] || [ ! -x "$SCRIPT_DIR/condense-error.sh" ]; then
    echo "$msg"
    return
  fi
  local condensed
  condensed=$("$SCRIPT_DIR/condense-error.sh" "$msg" 2>/dev/null || true)
  echo "${condensed:-$msg}"
}

# ============================================================
# Fix routing — pick the right fix based on diagnosis
# ============================================================
try_fix_session() {
  local fix_cmd="$1"
  echo "🔧 Fixing corrupted session..."
  if eval "$fix_cmd" 2>&1; then
    echo "✅ Session repaired"
    # Restart gateway to pick up the fixed session
    if systemctl --user restart openclaw-gateway 2>/dev/null; then
      echo "✅ Gateway restarted after session fix"
      return 0
    fi
  fi
  echo "❌ Session fix failed"
  return 1
}

# ============================================================
# Main check — diagnose then route
# ============================================================
do_check() {
  local current_state=$(get_state)
  local failures=$(get_failures)

  echo "[$(date -Iseconds)] Checking health..."

  local diag_json=""
  local diag_status=0
  diag_json=$(run_diagnosis) || diag_status=$?

  if [ "$diag_status" -eq 0 ]; then
    # Healthy — clear everything
    if [ "$current_state" != "HEALTHY" ]; then
      echo "✅ Recovered! State: $current_state -> HEALTHY"
      [ -x "$SCRIPT_DIR/notify.sh" ] && "$SCRIPT_DIR/notify.sh" "✅ [$AGENT_NAME] Recovered from $current_state"
      rm -f "$LOCK_FILE"
    fi
    update_state "HEALTHY" 0 ""
    echo "✅ HEALTHY"
    return 0
  fi

  # Issues found — determine what and how to fix
  local errors
  errors=$(get_error_summary "$diag_json")
  failures=$((failures + 1))
  echo "⚠️ Check failed ($failures/$FAIL_THRESHOLD): $errors"

  local has_session_corrupt
  has_session_corrupt=$(has_finding "$diag_json" "session_corrupted")
  local has_gateway_down
  has_gateway_down=$(has_finding "$diag_json" "gateway_down")

  # Session corruption with gateway still running = lightweight fix
  if [ "$has_session_corrupt" = "yes" ] && [ "$has_gateway_down" != "yes" ]; then
    echo "🔍 Diagnosis: session corrupted (gateway still running)"
    local fix_cmd
    fix_cmd=$(get_fix_command "$diag_json" "session_corrupted")
    if [ -n "$fix_cmd" ] && try_fix_session "$fix_cmd"; then
      update_state "HEALTHY" 0 ""
      [ -x "$SCRIPT_DIR/notify.sh" ] && "$SCRIPT_DIR/notify.sh" "✅ [$AGENT_NAME] Session corruption auto-fixed"
      return 0
    fi
    echo "❌ Session fix failed, escalating to resurrection"
  fi

  # Gateway down or fix failed — use threshold + resurrection flow
  if [ "$failures" -ge "$FAIL_THRESHOLD" ]; then
    if [ "$current_state" != "DEAD" ]; then
      echo "☠️ State: $current_state -> DEAD"
      update_state "DEAD" "$failures" "$errors"
      local condensed_errors
      condensed_errors=$(condense_error_msg "$errors")
      [ -x "$SCRIPT_DIR/notify.sh" ] && "$SCRIPT_DIR/notify.sh" "☠️ [$AGENT_NAME] DEAD! Errors: $condensed_errors. Starting recovery..."
      launch_resurrection
      return 2
    fi

    # Already DEAD — retry if cooldown elapsed
    update_state "DEAD" "$failures" "$errors"
    if ! is_resurrection_running; then
      if should_retry_resurrection; then
        echo "🔄 Retrying resurrection (previous attempt failed)"
        [ -x "$SCRIPT_DIR/notify.sh" ] && "$SCRIPT_DIR/notify.sh" "🔄 [$AGENT_NAME] Retrying resurrection..."
        launch_resurrection
      fi
    fi
  else
    update_state "CHECKING" "$failures" "$errors"
  fi

  return 1
}

# ============================================================
# Main
# ============================================================
echo "=== AMCP Watchdog ==="
echo "Agent: $AGENT_NAME"
echo "State file: $STATE_FILE"

if [ "$CONTINUOUS" = "--continuous" ]; then
  echo "Mode: Continuous (checking every ${CHECK_INTERVAL}s)"
  [ -x "$SCRIPT_DIR/notify.sh" ] && "$SCRIPT_DIR/notify.sh" "🔄 [$AGENT_NAME] Watchdog started (continuous mode)"

  while true; do
    do_check || true
    sleep "$CHECK_INTERVAL"
  done
else
  echo "Mode: Single check"
  do_check
  exit $?
fi
